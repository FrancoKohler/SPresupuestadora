const preciosDafne = {
    comunDAFB: [
      { material: "SERIE 2", precio: 792 },
      { material: "SERIE 3", precio: 827 },
      { material: "SERIE 4", precio: 861 },
      { material: "SERIE 5", precio: 905 },
    ],
 
  };
  const piezasDafne = [
    {
      id: "None",
      title: "Sin pieza seleccionada",
      imageUrl: "..",
      categoria: "DAFNE",
    },
    // New pieces with arms added below
    {
      id: "DAFB",
      title: "DAFB Butaca",
      imageUrl:
        "https://francokohler.github.io/SPresupuestadoraImg/MODELOS/DAFNE/DAFB-01.png",
      price: preciosDafne.comunDAFB,
      categoria: "BUTACA",
      medidap: 80,
      medida: 78,
    },
   
  ];
  